package com.example.watermeterlora;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class fetchData extends AsyncTask<Void, Void, Void> {


    String data = "";
    String dataParsed = "";
    String singleParsed = "";

    getLoraMeterData g=new getLoraMeterData ();


    @Override
    protected Void doInBackground(Void... voids) {
        try{

           g.receivedList = new ArrayList<> ();
           g.receivedAdapter = new ReceivedAdapter (g.getApplicationContext (), g.receivedList);


            URL url = new URL("http://www.wtsrv.dma-bd.com/watermeter/testandroid/testsql.php");
            HttpURLConnection httpURLConnection =   (HttpURLConnection) url.openConnection();

            InputStream inputStream =httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(inputStream)));

            String line = "";
            while (line != null){
                line= bufferedReader.readLine();
                data = data + line;
            }

            JSONArray JA = new JSONArray(data);
            for (int i=0;i < JA.length();i++)
            {
                JSONObject JO = (JSONObject) JA.get(i);
                String valveStatus ="";
                if(JO.get("valveStatus").toString() == "0"){
                    valveStatus ="Close";
                }else if(JO.get("valveStatus").toString() == "1"){
                    valveStatus ="Open";
                }

                ReceivedItemClass r =  new ReceivedItemClass ();

                r.setSerial (JO.get("number").toString ());
                r.setMaterAddress (JO.get("MeterAddr").toString ());
                r.setMeterReading (JO.get("MeterReading").toString ());
                r.setValveStatus (JO.get("valveStatus").toString ());
                r.setDatetime (JO.get("datetimee").toString ());



                g.receivedList.add (r);

//                singleParsed = "Serial: " + JO.get("number") + "\n" +
//                        "Meter Address: " + JO.get("MeterAddr") + "\n" +
//                        "Meter Reading: " + JO.get("MeterReading") + "\n" +
//                        "Valve Status: " + JO.get("valveStatus") + "\n" +
//                        "Date Time: " + JO.get("datetimee") + "\n";
//                        dataParsed = dataParsed + singleParsed + "\n";


            }
            g.receivedAdapter.notifyDataSetChanged ();


        } catch (MalformedURLException e) {
            e.printStackTrace();
          } catch (IOException e) {
        }catch (JSONException e) {
        }

        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid)
    {
        super.onPostExecute(aVoid);
    }

}
