package com.example.watermeterlora;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;


public class getLoraMeterData extends AppCompatActivity {

    String data = "";
    public RecyclerView rList;
    public LinearLayoutManager linearLayoutManager;
    public DividerItemDecoration dividerItemDecoration;
    public ArrayList<ReceivedItemClass> receivedList;
    public ReceivedAdapter receivedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_get_lora_meter_data);

        Intent intent = getIntent ();
        String name = intent.getStringExtra ("name");
        String full_name = intent.getStringExtra ("full_name");

        rList=(RecyclerView)findViewById(R.id.receivedList);
        receivedList=new ArrayList<>();
        receivedAdapter=new ReceivedAdapter(getApplicationContext(),receivedList);
        linearLayoutManager=new LinearLayoutManager(getApplicationContext());
        dividerItemDecoration=new DividerItemDecoration(rList.getContext(),linearLayoutManager.getOrientation());

        rList.setHasFixedSize(true);
        rList.setLayoutManager(linearLayoutManager);
        rList.addItemDecoration(dividerItemDecoration);
        rList.setAdapter(receivedAdapter);

        fetchData ();
    }

    private void fetchData(){
        AsyncTask<Void, Void, Void> task=new AsyncTask<Void, Void, Void> () {
            @Override
            protected Void doInBackground(Void... voids) {
                try{
                    URL url = new URL("http://www.wtsrv.dma-bd.com/watermeter/testandroid/testsql.php");
                    HttpURLConnection httpURLConnection =   (HttpURLConnection) url.openConnection();

                    InputStream inputStream =httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader((new InputStreamReader (inputStream)));

                    String line = "";
                    while (line != null){
                        line= bufferedReader.readLine();
                        data = data + line;
                    }

                    JSONArray JA = new JSONArray(data);
                    for (int i=0;i < JA.length();i++)
                    {
                        JSONObject JO = (JSONObject) JA.get(i);
                        String valveStatus ="";
                        if(JO.get("valveStatus").toString() == "0"){
                            valveStatus ="Close";
                        }else if(JO.get("valveStatus").toString() == "1"){
                            valveStatus ="Open";
                        }

                        Log.e ("Valve Status", valveStatus);
                        System.out.println(valveStatus);

                        ReceivedItemClass r =  new ReceivedItemClass ();

                        //r.setSerial ("Serial: " + JO.get("number").toString ());
                        r.setSerial (JO.get("number").toString ());
                        r.setMaterAddress ("Meter Address: " +JO.get("MeterAddr").toString ());
                        r.setMeterReading ("MeterReading: " +JO.get("MeterReading").toString ());
                        r.setValveStatus ("Valve Status: " +JO.get("valveStatus").toString ());


//                        String[] parts = JO.get("datetimee").toString ().split(".");
//                        String part1 = parts[0];
                        r.setDatetime ("Updated: " +JO.get("datetimee").toString ());
                        receivedList.add (r);
                    }
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                }catch (JSONException e) {
                }

                return null;
            }
            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                receivedAdapter.notifyDataSetChanged ();
            }
        };
        task.execute ();
    }
}
