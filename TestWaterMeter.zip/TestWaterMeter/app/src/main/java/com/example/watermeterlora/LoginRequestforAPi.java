
package com.example.watermeterlora;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class LoginRequestforAPi extends StringRequest{

    private static final String LOGIN_REQUEST_URL = "http://192.168.4.118:8080/student_info";
    private Map<String, String> params;

    public LoginRequestforAPi(String updated_time, String class_id, Response.Listener<String> listener) {
        super(Method.POST, LOGIN_REQUEST_URL, listener, null);
        params = new HashMap<>();
        params.put("updated_time", "2019-01-29 11:17:42");
        params.put("class_id", "1");
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
