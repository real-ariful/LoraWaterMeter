package com.example.watermeterlora;



public class ReceivedItemClass {
    public String Serial;
    public String MaterAddress;
    public String MeterReading;
    public String ValveStatus;
    public String Datetime;

    public ReceivedItemClass(String serial, String materAddress, String meterReading, String valveStatus, String datetime) {
        Serial = serial;
        MaterAddress = materAddress;
        MeterReading = meterReading;
        ValveStatus = valveStatus;
        Datetime = datetime;
    }


    public ReceivedItemClass() {
    }

    public String getSerial() {
        return Serial;
    }

    public String getMaterAddress() {
        return MaterAddress;
    }

    public String getMeterReading() {
        return MeterReading;
    }

    public String getValveStatus() {
        return ValveStatus;
    }

    public String getDatetime() {
        return Datetime;
    }


    public void setSerial(String serial) {
        Serial = serial;
    }

    public void setMaterAddress(String materAddress) {
        MaterAddress = materAddress;
    }

    public void setMeterReading(String meterReading) {
        MeterReading = meterReading;
    }

    public void setValveStatus(String valveStatus) {
        ValveStatus = valveStatus;
    }

    public void setDatetime(String datetime) {
        Datetime = datetime;
    }
}
