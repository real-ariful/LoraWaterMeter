package com.example.watermeterlora;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class TestAPI extends AppCompatActivity {

    Button btnTestApi;
    //Button btnGetLoraData = (Button) findViewById (R.id.btnGetLoraData);
    TextView tvJson2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_test_api);
        //Toolbar toolbar = findViewById (R.id.toolbar);
        //setSupportActionBar (toolbar);

//        FloatingActionButton fab = findViewById (R.id.fab);
//        fab.setOnClickListener (new View.OnClickListener () {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make (view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction ("Action", null).show ();
//            }
//        });

        btnTestApi.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v)
            {

//                Response.Listener<String> responseListener = new Response.Listener<String> () {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject jsonResponse = new JSONObject (response);
//                            //boolean error = jsonResponse.getBoolean ("error");
//                            //tvjsonResponse.setText (jsonResponse.toString ());
//
//                            //if((jsonResponse.getBoolean ("error")) == false){
//                            //String name = jsonResponse.getString ("user_name");
//                            //String full_name = jsonResponse.getString ("full_name");
//
//                            Intent intent = new Intent (TestAPI.this, LoginRequestforAPi.class);
//                            startActivity (intent);
//                            //intent.putExtra ("name", name);
//                            //intent.putExtra ("full_name", full_name);
//                        } catch (JSONException e1) {
//                            e1.printStackTrace ();
//                        }
//                    }
//                };
//
//                LoginRequestforAPi loginRequestforAPi = new LoginRequestforAPi ("2019-01-29 11:17:42", "1", responseListener);
//                RequestQueue queue = Volley.newRequestQueue (TestAPI.this);
//                queue.add (loginRequestforAPi);


            }
        });
    }

}
