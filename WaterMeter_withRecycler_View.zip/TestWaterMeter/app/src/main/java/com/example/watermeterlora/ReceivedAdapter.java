package com.example.watermeterlora;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ReceivedAdapter extends RecyclerView.Adapter<ReceivedAdapter.ViewHolder>{

    private Context context;
    private ArrayList<ReceivedItemClass> list;

    private int lastSelectedPosition = -1;



    public ReceivedAdapter(Context context, ArrayList<ReceivedItemClass> list){
        this.context=context;
        this.list=list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //View v = LayoutInflater.from(context).inflate(R.layout.single_received_view, parent, false);
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_listitem, parent, false);
        ViewHolder vh=new ViewHolder(v);
        return vh;
    }


    @Override
    public void onBindViewHolder(@NonNull final ReceivedAdapter.ViewHolder viewHolder, int i) {
        final ReceivedItemClass receivedItemClass=list.get(i);

        viewHolder.Serial.setText (receivedItemClass.getSerial ());
        viewHolder.MaterAddress.setText (receivedItemClass.getMaterAddress ());
        viewHolder.MeterReading.setText (receivedItemClass.getMeterReading ());
        viewHolder.ValveStatus.setText (receivedItemClass.getValveStatus ());
        viewHolder.Datetime.setText (receivedItemClass.getDatetime ());


//       // viewHolder.id.setText(receivedItemClass.getId());
//        //viewHolder.uid.setText(receivedItemClass.getuId());
//        viewHolder.linearLayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                //Toast.makeText(context,tankClass.getTank_name(),Toast.LENGTH_SHORT).show();
//                receivedItemClass.setSelected(!receivedItemClass.isSelected());
//                viewHolder.itemView.setBackgroundColor(receivedItemClass.isSelected() ? Color.CYAN : Color.WHITE);
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

//    public void filterList(ArrayList<ReceivedItemClass> filteredlist){
//        list=filteredlist;
//        notifyDataSetChanged();
//    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView Serial, MaterAddress, MeterReading, ValveStatus, Datetime;
        LinearLayout linearLayout;
        private View view;

        public ViewHolder(View itemView) {
            super(itemView);
            Serial=itemView.findViewById(R.id.Serial);
            MaterAddress=itemView.findViewById(R.id.MaterAddress);
            MeterReading=itemView.findViewById(R.id.MeterReading);
            ValveStatus=itemView.findViewById(R.id.ValveStatus);
            Datetime=itemView.findViewById(R.id.Datetime);


        }
    }
}
