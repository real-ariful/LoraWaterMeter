package com.example.watermeterlora;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin, btnRegister, btnForgetPassword;
    TextView tvjsonResponse;
    TextView tvShowResponse;

    private int counter = 5;

    public static TextView tvJson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText etUsername=(EditText)findViewById (R.id.etUsername);
        final EditText etPassword=(EditText)findViewById (R.id.etPassword);
        final Button btnLogin=(Button)findViewById (R.id.btnLogin);
        final Button btnRegister=(Button)findViewById (R.id.btnRegister);
        final Button btnForgetPassword=(Button)findViewById (R.id.btnForgetPassword);

        //final Button btnTest=(Button)findViewById (R.id.btnTest);
        //        btnTest.setOnClickListener (new View.OnClickListener () {
        //            @Override
        //            public void onClick(View v) {
        //                Intent testapi = new Intent (MainActivity.this, TestAPI.class);
        //                startActivity (testapi);
        //            }
        //        });

        btnRegister.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v) {
                Intent newRegister = new Intent (MainActivity.this, RegisterActivity.class);
                startActivity (newRegister);
            }
        });

        btnLogin.setOnClickListener (new View.OnClickListener () {
            @Override
            public void onClick(View v)
            {
//                                Intent intent = new Intent (MainActivity.this, getLoraMeterData.class);
//                                startActivity (intent);


//                tvShowResponse.setText ("Login Button has been clicked");
//                try {
//                    validate (etUsername.getText().toString().trim (), etPassword.getText().toString ().trim ());
//                } catch (InterruptedException e) {
//                    e.printStackTrace ();
//                }
//
//              tvShowResponse.setText ("Login Button Clickeed");
                final String username = etUsername.getText ().toString ();
                final String password = etPassword.getText ().toString ();

                if (username == "" && password == "")
                {
                    AlertDialog.Builder builder =  new AlertDialog.Builder (MainActivity.this);
                    builder.setMessage ("Please enter username and password");
                    builder.setNegativeButton ("Retry", null);
                    builder.create ();
                    builder.show();
                }



                Response.Listener<String> responseListener = new Response.Listener<String> ()
                {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject (response);
                            boolean error = jsonResponse.getBoolean ("error");
                            //tvjsonResponse.setText (jsonResponse.toString ());

                            if((jsonResponse.getBoolean ("error")) == false){
                                //String name = jsonResponse.getString ("user_name");
                                //String full_name = jsonResponse.getString ("full_name");

                                Intent intent = new Intent (MainActivity.this, getLoraMeterData.class);
                                startActivity (intent);
                                //intent.putExtra ("name", name);
                                //intent.putExtra ("full_name", full_name);
                            }
                            else
                            {
                                AlertDialog.Builder builder =  new AlertDialog.Builder (MainActivity.this);
                                builder.setMessage ("Login Failed!");
                                builder.setNegativeButton ("Retry", null);
                                builder.create ();
                                builder.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace ();
                        }
                    }
                };

                LoginRequest loginRequest = new LoginRequest(username, password, responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(loginRequest);
            }
        });

    }

        private void validate(String userName, String userPassword) throws InterruptedException {

        if(userName.toString () == "admin"){
            tvShowResponse.setText ("Correct username");
            if(userPassword == "admin")
            {
                tvShowResponse.setText ("Correct password");
            }
        }
        else{
            tvShowResponse.setText ("Incorrect username");
        }

            if((userName.toString () == "admin") && (userPassword == "admin"))
            {
                Intent intent = new Intent(MainActivity.this,
                        com.example.watermeterlora.getLoraMeterData.class);
                startActivity (intent);
            }

            else
            {
                counter--;
                tvShowResponse.setText (userName + userName.length()+ userPassword+userPassword.length() );
                //tvShowResponse.setText ("Processing");
                //tvShowResponse.setText ("PLease enter currect credentials");
                if(counter == 0)
                {
                    btnLogin.setEnabled (false);
                }

            }
        }





}
